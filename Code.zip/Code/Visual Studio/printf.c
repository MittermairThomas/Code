#include <stdio.h>
#include <time.h>

int main() {
    printf("Hello world");
    

    return 0;
}