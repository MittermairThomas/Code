name = input('Enter Name: ')

if (name == 'Thomas Mittermair'):
    password = input('Password eingeben: ')
    if(password == '070608'):
        print('Freigabe erteilt')
        print('')
        print('Username register: 22mittho')

else:
    print('Freigabe Verweigert')


input('')    #Keep programme open 