using System;

class Program {
    static void Main(string[] args) {
        Console.Write("Hello world");
    }
}