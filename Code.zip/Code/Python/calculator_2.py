import math

s = 'n'

while s == 'n':
    print("1_+")
    print("2_-")
    print("3_*")
    print("4_/")
    print("5_^x")
    print("6_sqrt")
    print("7_root")
    print("8_f(x)")
    print()

    o = int(input("Coose operation: "))

    if o == 1:
        m = float(input("Enter first number: "))
        n = float(input("Enter second numer: "))

        q = m + n
        print(q)
        print()

    if o == 2:
        m = float(input("Enter first number: "))
        n = float(input("Enter second numer: "))

        q = m - n
        print(q)
        print()

    if o == 3:
        m = float(input("Enter first number: "))
        n = float(input("Enter second numer: "))

        q = m * n
        print(q)
        print()

    if o == 4:
        m = float(input("Enter first number: "))
        n = float(input("Enter second numer: "))

        q = m / n
        print(q)
        print()

    if o == 5:
        m = float(input("Enter base: "))
        n = float(input("Enter exponend: "))

        q = m ** n
        print(q)
        print()

    if o == 6:
        m = float(input("Enter number: "))

        q = math.sqrt(m)
        print(q)
        print()

    if o == 7:
        m = float(input("Enter rootexponend: "))
        n = float(input("Enter base: "))

        x = 1 / m
        q = n ** x
        print(q)
        print()

    if o == 8:
        print("rad")
        print("-> 1: sinx")
        print("-> 2: arcsinx")
        print("-> 3: sinhx")
        print("-> 4: cosx")
        print("-> 5: arccosx")
        print("-> 6: coshx")
        print("-> 7: tanx")
        print("-> 8: arctanx")
        print("-> 9: tanhx")
        print()
        print("-> 10: logx")

        f = int(input("Enter funkton: "))

        if f == 1:
            m = float(input("Enter x-value: "))
            q = math.sin(m)

            print(q)
            print()

        if f == 2:
            m = float(input("Enter x-value: "))
            q = math.asin(m)

            print(q)
            print()

        if f == 3:
            m = float(input("Enter x-value: "))
            q = math.sinh(m)

            print(q)
            print()

        if f == 4:
            m = float(input("Enter x-value: "))
            q = math.cos(m)

            print(q)
            print()

        if f == 5:
            m = float(input("Enter x-value: "))
            q = math.acos(m)

            print(q)
            print()

        if f == 6:
            m = float(input("Enter x-value: "))
            q = math.cosh(m)

            print(q)
            print()

        if f == 7:
            m = float(input("Enter x-value: "))
            q = math.tan(m)

            print(q)
            print()

        if f == 8:
            m = float(input("Enter x-value: "))
            q = math.atan(m)

            print(q)
            print()

        if f == 9:
            m = float(input("Enter x-value: "))
            q = math.tanh(m)

            print(q)
            print()

        if f == 10:
            m = float(input("Enter x-value: "))
            q = math.log10(m)

            print(q)
            print()

        else:
            print("Error: Enter proper operation")
            print()

    else:
        print("Error: Enter proper operation")
        print()

    s = input("Stop programm? [y/n] ")
    print()
