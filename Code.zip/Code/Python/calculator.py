n = float(input("Enter first number: "))
m = float(input("Enter second number: "))

print("1__+")
print("2__-")
print("3__*")
print("4__/")

o = int(input("Enter operator: "))

if o == 1:
    a = float(n + m)
    c = "+"

if o == 2:
    a = float(n - m)
    c = "-"

if o == 3:
    a = float(n * m)
    c = "*"

if o == 4:
    a = float(n / m)
    c = "/"

print(str(n) + " " + c + " " + str(m) + " = " + str(a))

print()
input("Press any key to close")