import math

runCode = True
h = 'ok'

q = 0
ans = 0

a = ''
b = ''
c = ''
d = ''
e = ''

while runCode:
    print("For help type: ?")
    o = input("[*] Enter operator/function: ")
    print()

    if o == '+' or o == '-' or o == '*' or o == '/' or o == '%':
        m = input("Enter first number: ")
        n = input("Enter second number: ")

        if m == 'pi':
            m = math.pi

        elif m == 'e':
            m = math.e

        elif m == 'ans':
            m = ans

        else:
            m = float(m)

        if n == 'pi':
            n = math.pi

        elif n == 'e':
            n = math.e

        else:
            n = float(n)

        if o == '+':
            q = m + n
            print(str(m) + ' + ' + str(n))

            e = d
            d = c
            c = b
            b = a

            a = str(m) + ' + ' + str(n) + ' = ' + str(q)

            print("-->", q)
            print()
        
        if o == '-':
            q = m - n
            print(str(m) + ' - ' + str(n))

            e = d
            d = c
            c = b
            b = a

            a = str(m) + ' - ' + str(n) + ' = ' + str(q)

            print("-->", q)
            print()

        if o == '*':
            q = m * n
            print(str(m) + ' * ' + str(n))

            e = d
            d = c
            c = b
            b = a

            a = str(m) + ' * ' + str(n) + ' = ' + str(q)

            print("-->", q)
            print()

        if o == '/':
            q = m / n
            print(str(m) + ' / ' + str(n))

            e = d
            d = c
            c = b
            b = a

            a = str(m) + ' / ' + str(n) + ' = ' + str(q)

            print("-->", q)
            print()

        if o == '%':
            q = m%n
            print(str(m) + '%' + str(n))

            e = d
            d = c
            c = b
            b = a

            a = str(m) + '%' + str(n) + ' = ' + str(q)

            print("-->", q)
            print()

    elif o == '^x' or o == 'root':
        m = input("Enter base: ")
        n = input("Enter (root)exponend: ")

        if m == 'pi':
            m = math.pi

        elif m == 'e':
            m = math.e

        elif m == 'ans':
            m = ans

        else:
            m = float(m)

        if n == 'pi':
            n = math.pi

        elif n == 'e':
            n = math.e

        elif n == 'ans':
            n = ans

        else:
            n = float(n)

        if o == '^x':
            q = m ** n
            print(str(m) + '^' + str(n))

            e = d
            d = c
            c = b
            b = a

            a = str(m) + '^' + str(n) + ' = ' + str(q)

            print("-->", q)
            print()

        if o == 'root':
            c = 1 / n
            q = m ** c
            print(str(m) + '^' + "1/" + str(n))

            e = d
            d = c
            c = b
            b = a

            a = str(m) + '^' + "1/" + str(n) + ' = ' + str(q)

            print("-->", q)
            print()

    elif o == 'sin' or o == 'arcsin' or o == 'cos' or o == 'arccos' or o == 'tan' or o == 'arctan':
        r = input("Use rad or deg? [r/d] ")
        
        if r == 'r':
            print("rad")

        else:
            print("deg")

        m = input("Enter x-value: ")

        if m == 'pi':
            m = math.pi

        elif m == 'e':
            m = math.e

        elif m == 'ans':
            m = ans

        else:
            m = float(m)
        
        if r == 'd':
            m = m * math.pi / 180

        if o == 'sin':
            q = math.sin(m)
            print("sin" + str(m))

            e = d
            d = c
            c = b
            b = a

            a = "sin" + str(m) + " = " + str(q)

            print("-->", q)
            print()

        if o == 'arcsin':
            q = math.asin(m)
            print("arcsin" + str(m))

            e = d
            d = c
            c = b
            b = a

            a = "arcsin" + str(m)  + " = " + str(q)

            print("-->", q)
            print()

        if o == 'cos':
            q = math.cos(m)
            print("cos" + str(m))

            e = d
            d = c
            c = b
            b = a

            a = "cos" + str(m) + " = " + str(q)

            print("-->", q)
            print()

        if o == 'arccos':
            q = math.acos(m)
            print("arccos" + str(m))

            e = d
            d = c
            c = b
            b = a

            a = "arccos" + str(m) + " = " + str(q)

            print("-->", q)
            print()

        if o == 'tan':
            q = math.tan(m)
            print("tan" + str(m))

            e = d
            d = c
            c = b
            b = a

            a = "tan" + str(m) + " = " + str(q)

            print("-->", q)
            print()

        if o == 'arctan':
            q = math.atan(m)
            print("arctan" + str(m))

            e = d
            d = c
            c = b
            b = a

            a = "arctan" + str(m) + " = " + str(q)

            print("-->", q)
            print()

    elif o == 'log' or o == 'ln' or o == 'sqrt':
        m = input("Enter number: ")

        if m == 'pi':
            m = math.pi

        elif m == 'e':
            m = math.e

        elif m == 'ans':
            m = ans

        else:
            m = float(m)

        if o == 'log':
            q = math.log10(m)
            print("log" + str(m))

            e = d
            d = c
            c = b
            b = a

            a = "log" + str(m)  + " = " + str(q)

            print("-->", q)
            print()

        if o == 'ln':
            q = math.log(m)
            print("ln" + str(m))#

            e = d
            d = c
            c = b
            b = a

            a = "ln" + str(m)   + " = " + str(q)

            print("-->", q)
            print()


        if o == 'sqrt':
            q = math.sqrt(m)
            print("sprt" + str(m))

            e = d
            d = c
            c = b
            b = a

            a = "sprt" + str(m)   + " = " + str(q)

            print("-->", q)
            print()

    elif o == 'e^x':
        m = input("Enter exponend: ")

        if m == 'pi':
            m = math.pi

        elif m == 'e':
            m = math.e

        elif m == 'ans':
            m = ans

        else:
            m = float(m)

        q = math.e ** m
        print("e^" + str(m))

        e = d
        d = c
        c = b
        b = a

        a = "e^" + str(m)  + " = " + str(q)

        print("-->", q)
        print()

    elif o == '?':
        print("Operators:")
        print()
        print("+")
        print("-")
        print("*")
        print("/")
        print("%")
        print("^x")
        print("sqrt")
        print("root")
        print()
        print("Functions:")
        print()
        print("sin")
        print("arcsin")
        print("cos")
        print("arccos")
        print("tan")
        print("arctan")
        print("e^x")
        print("ln")
        print("log")
        print()
        print("Constants:")
        print()
        print("pi")
        print("e")
        print()
        print("System:")
        print()
        print("MEMORY")
        print()
        print("save")
        print("ans")
        print("clear")
        print()
        print("stop")
        print()

        h  = input("For help write spasific operation or 'ok' if not needed: ")

        if h != 'ok':
            if h == 'MEMORY':
                print("'MEMORY' lists the last 5 calculations and the variable 'ans'.")

            elif h == 'save':
                print("'save' saves the last answer into the variable 'ans'.")

            elif h == 'ans':
                print("'ans' lists the last answer saved by using 'save'.")

            elif h == 'clear':
                print("'clear' delites 'MEMORY' and 'ans'")

            elif h == 'stop':
                print("'stop' ends the programm")

            else:
                print("'help' was only defined for system functions.")

        print()
              
    elif o == 'MEMORY':
        print("-->", e)
        print("-->", d)
        print("-->", c)
        print("-->", b)
        print("-->", a)
        print()
        print("ans = " + str(ans))
        print()

    elif o == 'save':
        ans = q
        print("ans = " + str(ans))
        print()

    elif o == 'clear':
        a = ''
        b = ''
        c = ''
        d = ''
        e = ''

        ans = 0

        print("-->", e)
        print("-->", d)
        print("-->", c)
        print("-->", b)
        print("-->", a)
        print()

        print("ans = " + str(ans))
        print()

    elif o == 'stop':
        runCode = False

    else:
        print("Error 404: Operator/function '" + o + "' not found")
        print()