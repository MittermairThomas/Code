h = int(input('Enter height: '))
r = int(input('Enter radius of Planet: '))
m = int(input('Enter mass of planet: '))

h = h + r
t = 0

while (h > r):
    a = 6.67*10^-11 * m/h^2
    s = a*0.01/2
    h = h-  s
    t = t + 0.1

print("t = " + str(t) + "s")

input('End programm')