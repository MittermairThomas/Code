#include <stdio.h>
#include <string.h>

char c;

int n;
int pointer;
int counter;
int array[25];

unsigned long long int summe;
unsigned long long int multiplikator;
unsigned long long key = 12312312379;
unsigned long long int decriptet_string;
unsigned long long int bin_multiplikator;
unsigned long long int bin_counter;
unsigned long long int ascii;
unsigned long long int x;
unsigned long long int p;
unsigned long long int d;
unsigned long long int sum;
unsigned long long int encriptet_string;

int main() {
    FILE* f;
    FILE* nf;

    f = fopen("encriptet.txt", "r");
    nf = fopen("decriptet.txt", "w");

    if (f != NULL) {
        while((c = fgetc(f)) != EOF) {
            if (c != '.') {
                if (c == '0') { n = 0; }
                if (c == '1') { n = 1; }
                if (c == '2') { n = 2; }
                if (c == '3') { n = 3; }
                if (c == '4') { n = 4; }
                if (c == '5') { n = 5; }
                if (c == '6') { n = 6; }
                if (c == '7') { n = 7; }
                if (c == '8') { n = 8; }
                if (c == '9') { n = 9; }

                memset(array, -1, 25);
                pointer = 0;
                array[pointer + 1] = n;
                pointer++;
            }

            if (c = '.') {
                multiplikator = 1;
                counter = 24;
                summe = 0;

                while (array[counter] >= 0) {
                    summe += array[counter] * multiplikator;
                    printf("%i", array[counter]);

                    multiplikator *= 10;
                    counter--;
                }

                encriptet_string = summe;
                decript(encriptet_string);
                converte(decriptet_string);

                summe = 0;
                counter = 0;
                multiplikator = 10^25;
            }
        }
    }
    
    return 0;
}

int decript(unsigned long long int in) {
    decriptet_string = encriptet_string / key;

    decriptet_string -= 79;
    decriptet_string /= 100;

    return decriptet_string;
}

int converte(unsigned long long int f) {
    bin_multiplikator = 1;
    bin_counter = 1;
    p = 10;

    for (int i = 1; i >= 128; i *= 2) {
        x = f/p;
        x *= p;

        d = abs(f - x);
        sum += d * bin_multiplikator;

        bin_multiplikator *= 2;
        p *= 10;
    }

    ascii = sum;
    printf("%i", ascii);
    return ascii;
}