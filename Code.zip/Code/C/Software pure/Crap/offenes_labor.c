#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int r;
char c;
char binaryString;
int encriptingString;

int binaryCharPointer = 0;
char binaryChar[8];

char fileData[4094];
unsigned long key = 675434679;
unsigned long long binaryInt;
unsigned long long encriptetString;

int main() {
    FILE* file;

    file = fopen("Hello_world.txt", "r");

	int fileByte = 0;
    if (file != NULL) {
        while((c = fgetc(file)) != EOF) {
            fileByte = (int) c;

            convertToBinary(c);
            
            addToRest(r);
        }
        binaryInt = (int)binaryString;

        encripte(binaryInt);

        fclose(file);

        file = fopen("Hello_worldx.txt", "w");

        fprintf(file, encriptetString);

        fclose(file);
    }

    else {
        printf("System can't open file");
    }

    return 0;
}

int convertToBinary(int cint) {
    int b = cint;
	int bb;

		int counter = 0;
		int array[100];
		memset(array, -1, sizeof(int) * 100);
		do{
        int d = b/2;
        int r = b%2;

				array[counter] = r;
				counter++;
				
				b = b / 2;
    	binaryChar[binaryCharPointer] = bb;
    	binaryCharPointer++;
    } while (b > 0 );

		int counter2 = 0;
		int array2[100];
		memset(array2, -1, sizeof(int) * 100);
		for (int i = 99; i >= 0; i--){
			if (array[i] != -1){
				printf("%i", array[i]);
				array2[counter2] = array[i];
				counter2++;
			}
		}
		printf("\n");
		
		for (int i = 0; i < 100; i++) {
			if (array[i] == -1)
				array[i] = 0;
		}

				for (int i = 0; i < 100; i++){
					printf("%i", array[i]);
				}
	
				printf("\n");

				for (int i = 0; i < 100; i++){
					printf("%i", array2[i]);
				}

		int summe = 0;
		int multiplikator = 1;
		for (int i = 7; i >= 0; i--){
			summe += binaryChar[i] * multiplikator;
			multiplikator *= 10;
		}
    /* int b = cint/2; */
    /* r = cint%2; */

    /* char bb = (char) r; */
    /* binaryChar[binaryCharPointer] = bb; */
    /* binaryCharPointer++; */
    
    /* // binaryChar = ""; */
    
    return r;
}
                                              
int encripte(unsigned long binaryInt) {

    encriptetString = binaryInt * key;

	return encriptetString;
}
