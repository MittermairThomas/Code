#include <stdio.h>

unsigned long long int x;
char text[20];

int main() {
    
}

