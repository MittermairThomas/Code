#include <stdio.h>

unsigned long binaryString;

void ConvertToBinary(char convertString) {                        
    
}