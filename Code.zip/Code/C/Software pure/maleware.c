#include <stdio.h>

int main() {
    FILE* file;

    file = fopen("Hello world.txt", "w");

    if (file != NULL) {
        fprintf(file, "Hello world");
    }

    else {
        printf("Error");

        return 1;
    }

    printf("Hello world");
    
    return 0;
}