#include <stdio.h>

int array[100];
int counter;

int main() {
    FILE* file;

    file = fopen("Hello world.txt", "w");
    if (file != NULL) {
        char i = fgetc(file);
    
        printf(i);
    }

    return 0;
}