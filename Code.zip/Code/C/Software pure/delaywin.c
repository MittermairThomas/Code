#include <stdio.h>
#include <windows.h>

int main() {
    printf("Hello world");
    Sleep(1000);
    printf("Hello world");

    return 0;
}