#include <stdio.h>

int n;

int main() {
    scanf("%d", &n);

    printf(n);

    scanf("");
    return 0;
}