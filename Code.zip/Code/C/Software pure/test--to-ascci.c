#include <stdio.h>
#include "mydelay.c"

int main() {
    char c = 'A';

    int num = (int)c;
    printf(num);

    delay(3000);
    return 0;
}