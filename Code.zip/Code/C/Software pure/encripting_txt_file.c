#include <stdio.h>
#include <stdlib.h>
#include "mydelay.c"

int main() {
    FILE* file;
    char fileData[2048];
    unsigned long key = 264956493676509739288645582094679;

    file = fopen("Hello_world.txt", "r");
    char c;

    while(!feof(file)) {
        fgets(fileData, 2048, file);
        printf(fileData);   
    }

    fclose(file);

    delay(3000);

    return 0;
}

