#include <stdio.h>

int main() {
    printf("LOL\n");
    printf("lol\n");

    return 0;
}