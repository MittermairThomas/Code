#include <stdio.h>
#include "mydelay.c"

int main() {    

    char ch;
    printf("Enter char: ");
    scanf("%c", &ch);
    int i = (int) ch;
    printf(i);

    delay(3000);
    return 0;
}