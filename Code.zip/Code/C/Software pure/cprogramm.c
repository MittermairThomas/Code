#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int r;
char c;
char binaryString;
char binaryChar;
char fileData[4094];
unsigned long key = 264956493676509739288645582094679;
unsigned long long binaryInt;
unsigned long long encriptetString;

int main() {
    FILE* file;

    file = fopen("Hello_world.txt", "r");

    if (file != NULL) {
        while((c = fgetc(file)) != EOF) {
            putchar(c);
            int i = (int) c;

            convertToBinary(c);
            addToRest(r);
        }
        binaryInt = (int) binaryString;

        encripte(binaryInt);

        fclose(file);

        file = fopen("Hello_worldxxx.txt", "w");

        fprintf(file, encriptetString);

        fclose(file);
    }

    else {
        printf("System can't open file");
    }

    return 0;
}

void convertToBinary(int cint) {
    
    while (cint >= 1) {
        int b = cint/2;
        int r = cint%2;

        char bb = (char) r;
        strcat(binaryChar, r);
    }

    int b = cint/2;
    r = cint%2;

    char bb = (char) r;
    strcat(r, binaryChar);
    
    binaryChar = "";
    
    return r;
}

//Take byte and add it to the rest off the data from the file            /
void addToRest(char addChar) {                                      // \/

    strcat(binaryString, addChar);
}

//Encripte data from file                                                /
void encripte(unsigned long encriptingString) {                     // \/
    binaryInt = encriptingString;

    encriptetString = binaryInt * key;
}