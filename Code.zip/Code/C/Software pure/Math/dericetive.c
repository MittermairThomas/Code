#include <stdio.h>
#include <math.h>

int main() {
    printf("%s", "Suck my cock");
    return 0;
}