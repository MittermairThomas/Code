#include <stdio.h>
#include <string.h>

char c;

long long unsigned int n;
long long unsigned int summe;
long long unsigned int multiplikator;
long long unsigned int encriptet_string;
long long unsigned int decriptet_string;
long long unsigned int key = 12379;

long long unsigned int array[25];
long long unsigned int pointer = 0;
long long unsigned int selector;

int main() {
    FILE* f;
    FILE* nf;

    f = fopen("encriptet.txt", "r");
    nf = fopen("decriptet.txt", "w");

    if (f != NULL) {
        while ((c = fgetc(f)) != EOF) {
            memset(array, -1, 25);
            array[0] = -2;
            pointer = 1;

            while (c != '.') {
                if (c == '0') { n = 0; }
                if (c == '1') { n = 1; }
                if (c == '2') { n = 2; }
                if (c == '3') { n = 3; }
                if (c == '4') { n = 4; }
                if (c == '5') { n = 5; }
                if (c == '6') { n = 6; }
                if (c == '7') { n = 7; }
                if (c == '8') { n = 8; }
                if (c == '9') { n = 9; }

                printf("%llu", n);

                array[pointer + 1] = n;
                pointer++;
            }

            if (c == '.') {
                summe = 0;
                selector = 25;
                multiplikator = 1;

                while (array[selector] > -2) {
                    if (array[selector] > -1) {
                        summe += array[selector] * multiplikator;

                        multiplikator *= 10;
                    }

                    selector--;
                }

                encriptet_string = summe;
                printf("%llu", encriptet_string);

                //decripte(encriptet_string);
                printf("%llu", decriptet_string);
            }
        }
    }

    return 0;
}

int decripte(long long unsigned int in) {
    decriptet_string = in / key;

    decriptet_string -= 79;
    decriptet_string /= 100;

    return decriptet_string;
}