#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE* file;

    file = fopen("test.txt", "w");
    fputs("Hello world\n", file);

    fclose(file);

    return 0;
}