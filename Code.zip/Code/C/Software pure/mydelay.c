#include <stdio.h>
#include <time.h>

void delay(int time) {
    clock_t start_time = clock();

    while (clock() < start_time + time) {
    }
}
