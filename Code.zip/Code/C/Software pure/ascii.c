#include <stdio.h>

int main() {
    char c;

    printf("Enter char: ");
    scanf("%c" ,&c);
    printf("%i\n", c);

    scanf("");
    return 0;
}